<?php
/**
 * Copies CSS/JS (and inline blocks) from the asset manifest into the bundle.
 *
 * @package WpGrapeExport
 */

namespace WpGrapeExport;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolves wp-content asset URLs to disk paths and stages them under
 * assets/wp-content/… plus assets/inline/… for inline style/script blocks.
 */
class Assets_Copier {

	/**
	 * Bundle writer.
	 *
	 * @var Bundle_Writer
	 */
	private $writer;

	/**
	 * @var string[]
	 */
	private $warnings = array();

	/**
	 * @var int
	 */
	private $copied_files = 0;

	/**
	 * @param Bundle_Writer $writer Bundle writer.
	 */
	public function __construct( Bundle_Writer $writer ) {
		$this->writer = $writer;
	}

	/**
	 * Copy all local assets referenced by the manifest and builder-specific CSS.
	 *
	 * @param array    $manifest  Asset manifest (stylesheets + scripts).
	 * @param int[]    $post_ids  Post IDs to pull Elementor per-page CSS for.
	 * @param string   $builder   Detected page builder.
	 * @return array{copied:int,warnings:string[],manifest:array}
	 */
	public function copy( array $manifest, array $post_ids = array(), $builder = 'elementor' ) {
		$builder  = $builder ? (string) $builder : 'elementor';
		$manifest = $this->copy_manifest_entries( $manifest );

		if ( 'elementor' === $builder ) {
			$this->copy_elementor_css( $post_ids );
			$this->copy_critical_elementor_css();
			$widget_assets = new Widget_Assets();
			$inventory     = $widget_assets->site_inventory( $post_ids );
			$this->copied_files += $widget_assets->copy_inventory( $this->writer, $inventory );
		} else {
			$this->copy_critical_block_theme_css();
			$this->copy_otter_runtime_assets();
		}

		return array(
			'copied'   => $this->copied_files,
			'warnings' => $this->warnings,
			'manifest' => $manifest,
		);
	}

	/**
	 * Font Awesome + Tailwind generator used by Otter Atomic Wind on uncached pages.
	 */
	private function copy_otter_runtime_assets() {
		$rels = array(
			'plugins/otter-blocks/build/atomic-wind/tailwind-generator-frontend.js',
			'plugins/otter-blocks/build/atomic-wind/animations-frontend.js',
			'plugins/otter-blocks/build/atomic-wind/style-animations-frontend.css',
			'plugins/otter-blocks/assets/fontawesome/css/all.min.css',
			'plugins/otter-blocks/assets/fontawesome/css/v4-shims.min.css',
			'plugins/otter-blocks/build/blocks/form/style.css',
			'plugins/otter-blocks/build/blocks/font-awesome-icons/style.css',
			'plugins/otter-blocks/build/blocks/icon-list/style.css',
			'plugins/otter-blocks/build/blocks/sharing-icons/style.css',
		);
		$this->copy_rel_list( $rels );

		$fa_webfonts = WP_CONTENT_DIR . '/plugins/otter-blocks/assets/fontawesome/webfonts';
		if ( is_dir( $fa_webfonts ) ) {
			$this->copy_font_dirs( array( 'plugins/otter-blocks/assets/fontawesome/webfonts' ) );
		}
	}

	/**
	 * @return string[]
	 */
	public function warnings() {
		return $this->warnings;
	}

	/**
	 * Copy stylesheet + script files and persist inline blocks.
	 *
	 * @param array $manifest Manifest.
	 * @return array Updated manifest (adds bundlePath where applicable).
	 */
	private function copy_manifest_entries( array $manifest ) {
		if ( isset( $manifest['stylesheets'] ) && is_array( $manifest['stylesheets'] ) ) {
			foreach ( $manifest['stylesheets'] as $i => $entry ) {
				$manifest['stylesheets'][ $i ] = $this->copy_entry( $entry, 'styles' );
			}
		}
		if ( isset( $manifest['scripts'] ) && is_array( $manifest['scripts'] ) ) {
			foreach ( $manifest['scripts'] as $i => $entry ) {
				$manifest['scripts'][ $i ] = $this->copy_entry( $entry, 'scripts' );
			}
		}
		return $manifest;
	}

	/**
	 * @param array  $entry Entry.
	 * @param string $kind  styles|scripts.
	 * @return array
	 */
	private function copy_entry( array $entry, $kind ) {
		$handle = isset( $entry['handle'] ) ? (string) $entry['handle'] : 'asset';
		$src    = isset( $entry['src'] ) ? (string) $entry['src'] : '';

		if ( $src ) {
			$rel = $this->wp_content_rel_from_url( $src );
			if ( $rel ) {
				$source = $this->resolve_source_path( $rel );
				if ( $source && is_readable( $source ) ) {
					$dest = 'assets/wp-content/' . $rel;
					if ( $this->writer->copy( $source, $dest ) ) {
						$entry['bundlePath'] = $dest;
						$this->copied_files++;
					}
				} else {
					$this->warnings[] = sprintf( 'Stylesheet/script file missing on disk: %s', $src );
				}
			}
		}

		$inline = null;
		if ( 'styles' === $kind && ! empty( $entry['inlineAfter'] ) ) {
			$inline = (string) $entry['inlineAfter'];
		}
		if ( 'scripts' === $kind ) {
			$parts = array();
			if ( ! empty( $entry['inlineBefore'] ) ) {
				$parts[] = (string) $entry['inlineBefore'];
			}
			if ( ! empty( $entry['inlineAfter'] ) ) {
				$parts[] = (string) $entry['inlineAfter'];
			}
			$inline = trim( implode( "\n", $parts ) );
		}

		if ( $inline ) {
			$ext  = 'styles' === $kind ? 'css' : 'js';
			$file = 'assets/inline/' . $kind . '/' . sanitize_file_name( $handle ) . '.' . $ext;
			$this->writer->write( $file, $inline );
			$entry['bundleInline'] = $file;
			$this->copied_files++;
		}

		return $entry;
	}

	/**
	 * Copy Elementor per-post/global CSS from uploads/elementor/css.
	 *
	 * @param int[] $post_ids Post IDs.
	 */
	private function copy_elementor_css( array $post_ids ) {
		$css_dir = WP_CONTENT_DIR . '/uploads/elementor/css';
		if ( ! is_dir( $css_dir ) ) {
			return;
		}

		$copied = array();
		foreach ( $post_ids as $post_id ) {
			$post_id = (int) $post_id;
			if ( ! $post_id ) {
				continue;
			}
			$file = $css_dir . '/post-' . $post_id . '.css';
			if ( is_readable( $file ) ) {
				$dest = 'assets/wp-content/uploads/elementor/css/post-' . $post_id . '.css';
				if ( $this->writer->copy( $file, $dest ) ) {
					$copied[ basename( $file ) ] = true;
					$this->copied_files++;
				}
			}
		}

		// Shared kit / global / custom widget styles.
		foreach ( glob( $css_dir . '/*.css' ) as $file ) {
			$base = basename( $file );
			if ( isset( $copied[ $base ] ) ) {
				continue;
			}
			if ( preg_match( '/^(global|post-\d+|custom-|base-).*\.css$/', $base ) ) {
				$dest = 'assets/wp-content/uploads/elementor/css/' . $base;
				if ( $this->writer->copy( $file, $dest ) ) {
					$this->copied_files++;
				}
			}
		}

		// Google fonts CSS + font files used by Elementor.
		$fonts_css_dir = WP_CONTENT_DIR . '/uploads/elementor/google-fonts/css';
		if ( is_dir( $fonts_css_dir ) ) {
			foreach ( glob( $fonts_css_dir . '/*.css' ) as $file ) {
				$base = basename( $file );
				$this->writer->copy( $file, 'assets/wp-content/uploads/elementor/google-fonts/css/' . $base );
				$this->copied_files++;
			}
		}
		$fonts_dir = WP_CONTENT_DIR . '/uploads/elementor/google-fonts/fonts';
		if ( is_dir( $fonts_dir ) ) {
			foreach ( glob( $fonts_dir . '/*' ) as $file ) {
				if ( ! is_file( $file ) ) {
					continue;
				}
				$this->writer->copy( $file, 'assets/wp-content/uploads/elementor/google-fonts/fonts/' . basename( $file ) );
				$this->copied_files++;
			}
		}
	}

	/**
	 * Always stage core Elementor / ElementsKit CSS even when enqueue missed them.
	 */
	private function copy_critical_elementor_css() {
		$rels = array(
			'plugins/elementor/assets/css/frontend.min.css',
			'plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css',
			'plugins/elementor/assets/lib/swiper/v8/css/swiper.min.css',
			'plugins/elementor/assets/css/conditionals/e-swiper.min.css',
			'plugins/elementor/assets/css/widget-heading.min.css',
			'plugins/elementor/assets/css/widget-image.min.css',
			'plugins/elementor/assets/css/widget-image-carousel.min.css',
			'plugins/elementor/assets/css/widget-icon-box.min.css',
			'plugins/elementor/assets/css/widget-icon-list.min.css',
			'plugins/elementor/assets/css/widget-divider.min.css',
			'plugins/elementor/assets/css/widget-social-icons.min.css',
			'plugins/elementor/assets/css/widget-counter.min.css',
			'plugins/elementor/assets/lib/animations/animations.min.css',
			'plugins/elementor-pro/assets/css/widget-form.min.css',
			'plugins/elementor-pro/assets/css/widget-nav-menu.min.css',
			'plugins/elementor-pro/assets/css/widget-carousel-module-base.min.css',
			'plugins/elementskit-lite/modules/elementskit-icon-pack/assets/css/ekiticons.css',
			'plugins/elementskit-lite/widgets/init/assets/css/widget-styles.css',
			'plugins/elementskit-lite/widgets/init/assets/css/responsive.css',
			'plugins/elementor/assets/lib/swiper/v8/swiper.min.js',
			'plugins/elementor/assets/js/webpack.runtime.min.js',
			'plugins/elementor/assets/js/frontend-modules.min.js',
			'plugins/elementor/assets/js/frontend.min.js',
			'plugins/elementor-pro/assets/js/webpack-pro.runtime.min.js',
			'plugins/elementor-pro/assets/js/frontend.min.js',
			'plugins/elementor-pro/assets/js/elements-handlers.min.js',
			'plugins/elementor-pro/assets/lib/smartmenus/jquery.smartmenus.min.js',
		);

		$this->copy_rel_list( $rels );

		$font_dirs = array(
			'plugins/elementor/assets/lib/eicons/fonts',
			'plugins/elementskit-lite/modules/elementskit-icon-pack/assets/fonts',
		);
		$this->copy_font_dirs( $font_dirs );
	}

	/**
	 * Stage Neve / Otter / block theme CSS for Gutenberg exports.
	 */
	private function copy_critical_block_theme_css() {
		$rels = array();

		foreach ( array( get_stylesheet(), get_template() ) as $theme ) {
			foreach ( array( 'assets/images', 'assets/fonts', 'assets/img' ) as $subdir ) {
				$dir = WP_CONTENT_DIR . '/themes/' . $theme . '/' . $subdir;
				if ( is_dir( $dir ) ) {
					$this->copy_font_dirs( array( 'themes/' . $theme . '/' . $subdir ) );
				}
			}
		}

		$theme_rel_candidates = array(
			'themes/' . get_stylesheet() . '/style-main-new.min.css',
			'themes/' . get_template() . '/style-main-new.min.css',
			'themes/' . get_stylesheet() . '/style-main.min.css',
			'themes/' . get_template() . '/style-main.min.css',
			'themes/' . get_stylesheet() . '/style.css',
			'themes/' . get_template() . '/style.css',
			'themes/' . get_stylesheet() . '/assets/css/mega-menu.min.css',
			'themes/' . get_template() . '/assets/css/mega-menu.min.css',
		);
		foreach ( $theme_rel_candidates as $rel ) {
			if ( is_readable( WP_CONTENT_DIR . '/' . $rel ) ) {
				$rels[] = $rel;
			}
		}

		$otter_globs = array(
			'plugins/otter-blocks/build/atomic-wind/style-animations-frontend.css',
			'plugins/otter-blocks/build/atomic-wind/style-animations-frontend-rtl.css',
			'plugins/otter-blocks/build/style.css',
			'plugins/otter-blocks/build/blocks/style.css',
			'plugins/otter-blocks/build/animation/index.css',
		);
		foreach ( $otter_globs as $rel ) {
			if ( is_readable( WP_CONTENT_DIR . '/' . $rel ) ) {
				$rels[] = $rel;
			}
		}

		// Block frontend styles only (skip editor CSS).
		$blocks_dir = WP_CONTENT_DIR . '/plugins/otter-blocks/build/blocks';
		if ( is_dir( $blocks_dir ) ) {
			foreach ( glob( $blocks_dir . '/*/style.css' ) ?: array() as $file ) {
				$rel    = ltrim( str_replace( WP_CONTENT_DIR, '', wp_normalize_path( $file ) ), '/' );
				$rels[] = $rel;
			}
		}

		$this->copy_rel_list( array_values( array_unique( $rels ) ) );
	}

	/**
	 * @param string[] $rels Paths under wp-content.
	 */
	private function copy_rel_list( array $rels ) {
		foreach ( $rels as $rel ) {
			$source = WP_CONTENT_DIR . '/' . $rel;
			if ( ! is_readable( $source ) ) {
				continue;
			}
			$dest = 'assets/wp-content/' . $rel;
			if ( $this->writer->copy( $source, $dest ) ) {
				$this->copied_files++;
			}
		}
	}

	/**
	 * @param string[] $font_dirs Paths under wp-content.
	 */
	private function copy_font_dirs( array $font_dirs ) {
		foreach ( $font_dirs as $dir_rel ) {
			$abs = WP_CONTENT_DIR . '/' . $dir_rel;
			if ( ! is_dir( $abs ) ) {
				continue;
			}
			foreach ( glob( $abs . '/*' ) as $file ) {
				if ( ! is_file( $file ) ) {
					continue;
				}
				if ( $this->writer->copy( $file, 'assets/wp-content/' . $dir_rel . '/' . basename( $file ) ) ) {
					$this->copied_files++;
				}
			}
		}
	}

	/**
	 * @deprecated Renamed to copy_critical_elementor_css().
	 */
	private function copy_critical_builder_css() {
		$this->copy_critical_elementor_css();
	}

	/**
	 * Extract the wp-content-relative path from an asset URL.
	 *
	 * @param string $url Asset URL.
	 * @return string|null
	 */
	private function wp_content_rel_from_url( $url ) {
		$url = preg_replace( '#\?.*$#', '', (string) $url );
		if ( preg_match( '#/wp-content/(.+)$#i', $url, $matches ) ) {
			return $matches[1];
		}
		return null;
	}

	/**
	 * Resolve a wp-content-relative path to an absolute source file.
	 *
	 * @param string $rel Relative path under wp-content.
	 * @return string|null
	 */
	private function resolve_source_path( $rel ) {
		$candidates = array(
			WP_CONTENT_DIR . '/' . $rel,
		);

		// Some manifests still reference /smartco/wp-content/… while the site runs at /.
		if ( 0 === strpos( $rel, 'smartco/' ) ) {
			$candidates[] = WP_CONTENT_DIR . '/' . substr( $rel, strlen( 'smartco/' ) );
		}

		foreach ( $candidates as $path ) {
			if ( is_readable( $path ) ) {
				return $path;
			}
		}

		return null;
	}
}
