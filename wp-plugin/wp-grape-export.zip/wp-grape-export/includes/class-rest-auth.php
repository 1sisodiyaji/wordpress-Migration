<?php
/**
 * REST authentication helpers for local development.
 *
 * @package WpGrapeExport
 */

namespace WpGrapeExport;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enables Basic-auth REST login with regular wp-admin passwords on localhost,
 * and always allows Application Passwords over plain HTTP for local/docker.
 */
class Rest_Auth {

	/**
	 * Register filters.
	 */
	public static function register() {
		add_filter( 'wp_is_application_passwords_available', array( __CLASS__, 'allow_app_passwords_on_http' ) );
		add_filter( 'determine_current_user', array( __CLASS__, 'authenticate_basic_local' ), 20 );
	}

	/**
	 * Allow Application Passwords on HTTP (required for docker localhost).
	 *
	 * @param bool $available Whether app passwords are available.
	 * @return bool
	 */
	public static function allow_app_passwords_on_http( $available ) {
		if ( $available ) {
			return true;
		}
		return self::is_local_request();
	}

	/**
	 * On localhost only, accept HTTP Basic auth with a normal wp-admin password.
	 *
	 * @param int|false $user_id Current user ID.
	 * @return int|false
	 */
	public static function authenticate_basic_local( $user_id ) {
		if ( $user_id ) {
			return $user_id;
		}
		if ( ! self::is_local_request() ) {
			return $user_id;
		}

		$creds = self::basic_credentials();
		if ( ! $creds ) {
			return $user_id;
		}

		$user = wp_authenticate( $creds['username'], $creds['password'] );
		if ( is_wp_error( $user ) ) {
			return $user_id;
		}

		return (int) $user->ID;
	}

	/**
	 * Whether the incoming request targets a local/dev host.
	 *
	 * @return bool
	 */
	public static function is_local_request() {
		$host = isset( $_SERVER['HTTP_HOST'] ) ? strtolower( (string) wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
		if ( $host && ( false !== strpos( $host, 'localhost' ) || false !== strpos( $host, '127.0.0.1' ) ) ) {
			return true;
		}

		$addr = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
		return in_array( $addr, array( '127.0.0.1', '::1' ), true );
	}

	/**
	 * Parse HTTP Basic credentials from the request.
	 *
	 * @return array{username:string,password:string}|null
	 */
	private static function basic_credentials() {
		$user = null;
		$pass = null;

		if ( isset( $_SERVER['PHP_AUTH_USER'] ) ) {
			$user = (string) wp_unslash( $_SERVER['PHP_AUTH_USER'] );
			$pass = isset( $_SERVER['PHP_AUTH_PW'] ) ? (string) wp_unslash( $_SERVER['PHP_AUTH_PW'] ) : '';
		} elseif ( isset( $_SERVER['HTTP_AUTHORIZATION'] ) ) {
			$header = (string) wp_unslash( $_SERVER['HTTP_AUTHORIZATION'] );
			if ( 0 === stripos( $header, 'basic ' ) ) {
				$decoded = base64_decode( substr( $header, 6 ), true );
				if ( $decoded && false !== strpos( $decoded, ':' ) ) {
					list( $user, $pass ) = array_pad( explode( ':', $decoded, 2 ), 2, '' );
				}
			}
		}

		if ( ! $user || '' === $pass ) {
			return null;
		}

		return array(
			'username' => $user,
			'password' => $pass,
		);
	}
}
