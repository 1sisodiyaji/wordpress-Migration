<?php
/**
 * REST API for programmatic exports (Studio integration).
 *
 * @package WpGrapeExport
 */

namespace WpGrapeExport\Rest;

use WpGrapeExport\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Exposes export endpoints under /wp-json/wp-grape-export/v1.
 */
class Controller {

	const NAMESPACE_V1 = 'wp-grape-export/v1';

	/**
	 * Register REST routes.
	 */
	public function register_routes() {
		register_rest_route(
			self::NAMESPACE_V1,
			'/ping',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'callback'            => array( $this, 'ping' ),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/export',
			array(
				'methods'             => 'POST',
				'permission_callback' => array( $this, 'can_export' ),
				'callback'            => array( $this, 'export' ),
				'args'                => array(
					'post_types' => array(
						'type'     => 'array',
						'required' => false,
						'items'    => array( 'type' => 'string' ),
					),
					'copy_media' => array(
						'type'     => 'boolean',
						'required' => false,
						'default'  => false,
					),
				),
			)
		);
	}

	/**
	 * Permission check for export.
	 *
	 * @return bool
	 */
	public function can_export() {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		if ( ! is_user_logged_in() ) {
			return new \WP_Error(
				'rest_not_logged_in',
				__( 'Authentication required. On localhost use your wp-admin username and password; otherwise create an Application Password under Users → Profile.', 'wp-grape-export' ),
				array( 'status' => 401 )
			);
		}
		return new \WP_Error(
			'rest_forbidden',
			__( 'The authenticated user must be an Administrator.', 'wp-grape-export' ),
			array( 'status' => 403 )
		);
	}

	/**
	 * Simple availability probe.
	 *
	 * @return \WP_REST_Response
	 */
	public function ping() {
		return rest_ensure_response(
			array(
				'ok'            => true,
				'plugin'        => 'wp-grape-export',
				'version'       => WPGE_VERSION,
				'schemaVersion' => WPGE_SCHEMA_VERSION,
			)
		);
	}

	/**
	 * Run an export and return the download URL + stats.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function export( $request ) {
		$post_types = $request->get_param( 'post_types' );
		$copy_media = (bool) $request->get_param( 'copy_media' );

		if ( empty( $post_types ) || ! is_array( $post_types ) ) {
			$post_types = array( 'page', 'post' );
		}
		$post_types = array_map( 'sanitize_key', $post_types );

		try {
			$result = Plugin::instance()->run_export(
				array(
					'post_types' => $post_types,
					'copy_media' => $copy_media,
				)
			);
		} catch ( \Throwable $e ) {
			return new \WP_Error( 'wpge_export_failed', $e->getMessage(), array( 'status' => 500 ) );
		}

		return rest_ensure_response(
			array(
				'ok'    => true,
				'url'   => $result['url'],
				'stats' => $result['stats'],
			)
		);
	}
}
